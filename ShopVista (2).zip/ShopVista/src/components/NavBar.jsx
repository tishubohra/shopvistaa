import { ShoppingCartIcon } from "@heroicons/react/24/outline";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";
import { Search } from "./";
import { firebaseAuth } from "./Firebase";
import { onAuthStateChanged, signOut } from "firebase/auth";
import { useStateValue } from "./Stateprovider";
import React from 'react';
import {Checkout} from './Checkout';
const NavBar = () => {
  const cart = useSelector((state) => state.cart.productsNumber);
  const [{ basket, user }, dispatch] = useStateValue();

  // Add a state to track whether the authentication state is being initialized
  const [authStateInitialized, setAuthStateInitialized] = React.useState(false);

  // Use useEffect to run the onAuthStateChanged listener only once
  React.useEffect(() => {
    const unsubscribe = onAuthStateChanged(firebaseAuth, (authUser) => {
      if (!authStateInitialized) {
        // Set the initialization state to true
        setAuthStateInitialized(true);
      }

      if (authUser) {
        // the user just logged in / the user was logged in
        dispatch({
          type: "SET_USER",
          user: authUser,
        });
      } else {
        // the user is logged out
        dispatch({
          type: "SET_USER",
          user: null,
        });
      }
    });

    // Cleanup the listener when the component unmounts
    return () => {
      unsubscribe();
    };
  }, [dispatch, authStateInitialized]);

  const handleAuthentication = () => {
    if (user) {
      signOut(firebaseAuth)
        .then(() => {
          // Handle successful sign-out here (e.g., redirect to home page)
          console.log('Sign-out successful');
        })
        .catch((error) => {
          // Handle sign-out errors here
          console.error('Error signing out:', error);
        });
    }
  };

  return (
    <header className="min-w-[1000px] border-black border-4 border solid">
      <div className="flex bg-teal-700 text-black h-[60px]">
        {/* Left */}
        <div className="flex items-center m-0">
          <Link to={"/"}>
            <img
              className="h-[60px] w-[100px] m-2"
              src={"../images/logo-png.png"}
              alt="Amazon logo"
            />
          </Link>
        </div>
        {/* Middle */}
        <div className="flex grow relative items-center  rounded-md py-2 px-4 ">
          <Search />
        </div>
        {/* Right */}
        <div className="flex items-center m-4">
          <div className="pr-4 pl-4">
            <Link to={"/Login"}>
              <div onClick={()=>handleAuthentication} className="text-xs xl:text-sm">Hello {!user ? 'Guest' : user.email}</div>
              <div className="text-sm xl:text-base font-bold">
                {user ? 'Sign Out' : 'Sign In'}
              </div>
            </Link>
          </div>
          <div className="pr-4 pl-4">
            <div className="text-xs xl:text-sm">Returns</div>
            <div className="text-sm xl:text-base font-bold">& Orders</div>
          </div>
         <Link to={"/Checkout"}>
            <div className="flex pr-3 pl-3">
              <ShoppingCartIcon className="h-[48px]" />
              <div className="relative">
                <div className="absolute right-[9px] font-bold m-2 text-orange-400">
                  {cart}
                </div>
              </div>
              <div className="mt-7 text-xs xl:text-sm font-bold">Cart</div>
            </div>
            </Link>
        </div>
      </div>
      <div className="bg-amazonclone-light_blue text-white text-xs xl:text-sm p-2 pl-6">
        <div className="flex space-x-3">
          <div className="hover:text-yellow-300">Today's Deals</div>
          <div className="hover:text-yellow-300">Customer Service</div>
          <div className="hover:text-yellow-300">Registry</div>
          <div className="hover:text-yellow-300">Gift Cards</div>
          <div className="hover:text-yellow-300">Sell</div>
        </div>
      </div>

    </header>
  );
};

export default NavBar;
