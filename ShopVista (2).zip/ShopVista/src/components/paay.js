// Import React and CSS
import React from 'react';
import './pay.css';

// PaymentSuccessful component
const PaymentSuccessful = () => {
  return (
    <div className="container">
      <div className="success-page">
        <h1>Thank You!</h1>
        <p>Your payment was successful.</p>
        <p>Thank you for shopping with ShopVista.</p>
      </div>
    </div>
  );
};

export default PaymentSuccessful;
