// HomePageCard.js
import React from 'react';
import { Link } from 'react-router-dom';

const HomePageCard = ({ title, img, link }) => {
  return (
    <div className="h-[420px] bg-white z-30 m-3 overflow-hidden hover:shadow-lg transition-transform duration-400 transform hover:scale-105">
      <div className="text-lg xl:text-xl font-bold ml-4 mt-4">{title}</div>
      <div className="h-[300px] m-4">
        <Link to={link}>
          <img
            className="h-[100%] w-[100%] object-cover border-3 border border-solid border-black transition-transform duration-300 transform hover:scale-105"
            src={img}
            alt="Home card"
          />
        </Link>
      </div>
      <div className="text-xs xl:text-sm text-blue-900 font-semibold ml-4">{link}</div>
    </div>
  );
};

export default HomePageCard;
