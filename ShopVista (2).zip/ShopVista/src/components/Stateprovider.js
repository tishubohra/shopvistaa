import React , {createContext , useContext, useReducer} from 'react';
//import reducer from './reducer';
//prepare the dataLayer
export const StateContext= createContext();
//Wrap our app and provide the Data Layer
export const Stateprovider= ( { reducer , initialState , children}) => (
  <StateContext.Provider value={useReducer(reducer, initialState)}>
      {children}
     
  </StateContext.Provider>
 
);
// pull the information from the data layer
export const useStateValue=()=> useContext(StateContext);
