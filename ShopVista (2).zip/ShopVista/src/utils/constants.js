export const BASE_URL = "..";
export const GB_CURRENCY = Intl.NumberFormat("en-GB", {
  style: "currency",
  currency: "GBP",
});
