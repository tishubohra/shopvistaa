import React, { useEffect } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import {
  HomePage,
  NavBar,
  SearchResults,
  ProductPage,
  Checkout
} from "./components";
import Login from "./components/Login";

import { onAuthStateChanged } from "firebase/auth";
import { useStateValue } from "./components/Stateprovider";
import { firebaseAuth } from "./components/Firebase";
import PaymentSuccessful from "./components/paay";
// Memoized components
const MemoizedHomePage = React.memo(HomePage);
const MemoizedSearchResults = React.memo(SearchResults);
const MemoizedLogin = React.memo(Login);
const MemoizedProductPage = React.memo(ProductPage);


const App = () => {
  const [{}, dispatch] = useStateValue();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(firebaseAuth, (authUser) => {
      if (authUser) {
        dispatch({
          type: "SET_USER",
          user: authUser,
        });
      } else {
        dispatch({
          type: "SET_USER",
          user: null,
        });
      }
    });

    // Cleanup the subscription when the component unmounts
    return () => unsubscribe();
  }, [dispatch]);

  return (
    <BrowserRouter>
      <NavBar />
      <Routes>
        <Route exact path="/" element={<MemoizedHomePage />} />
        <Route path="/search" element={<MemoizedSearchResults />} />
        <Route path="/Login" element={<MemoizedLogin />} />
        <Route path="/product/:id" element={<MemoizedProductPage />} />
        <Route path="/Checkout" element={<Checkout />} />
        <Route path="/pay" element={<PaymentSuccessful/>} />
      </Routes>
    </BrowserRouter>
  );
};

export default App;
